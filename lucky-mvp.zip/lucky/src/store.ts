import { randomUUID } from "node:crypto";
import type { DatabaseSync } from "node:sqlite";

export type Status = "PENDING" | "RUNNING" | "BLOCKED" | "AWAITING_APPROVAL" | "COMPLETED" | "FAILED" | "CANCELLED";
export type Criterion =
  | { type: "file_exists"; path: string }
  | { type: "file_contains"; path: string; text: string }
  | { type: "command_ok"; command: string };
export interface Mission { id: string; goal: string; status: Status; criteria: Criterion[]; result: string; created: string }
export type Confidence = "observed" | "inferred" | "confirmed";

export class Store {
  private db: DatabaseSync;
  constructor(db: DatabaseSync) {
    this.db = db;
    db.exec(`CREATE TABLE IF NOT EXISTS missions(
      id TEXT PRIMARY KEY, goal TEXT, status TEXT, criteria TEXT, result TEXT, created TEXT);
      CREATE TABLE IF NOT EXISTS memory(
      id INTEGER PRIMARY KEY AUTOINCREMENT, confidence TEXT, text TEXT, source TEXT, created TEXT);`);
  }
  createMission(goal: string): Mission {
    const m: Mission = { id: randomUUID().slice(0, 8), goal, status: "PENDING", criteria: [], result: "", created: new Date().toISOString() };
    this.db.prepare("INSERT INTO missions VALUES(?,?,?,?,?,?)").run(m.id, m.goal, m.status, "[]", "", m.created);
    return m;
  }
  getMission(id: string): Mission | undefined {
    const r = this.db.prepare("SELECT * FROM missions WHERE id=?").get(id) as Record<string, string> | undefined;
    return r && { id: r.id, goal: r.goal, status: r.status as Status, criteria: JSON.parse(r.criteria), result: r.result, created: r.created };
  }
  listMissions(): Mission[] {
    const ids = this.db.prepare("SELECT id FROM missions ORDER BY created").all() as Array<{ id: string }>;
    return ids.map((r) => this.getMission(r.id)!);
  }
  setStatus(id: string, status: Status, result = ""): void {
    this.db.prepare("UPDATE missions SET status=?, result=? WHERE id=?").run(status, result, id);
  }
  addCriterion(id: string, c: Criterion): void {
    const m = this.getMission(id);
    if (!m) throw new Error("Missão não encontrada");
    this.db.prepare("UPDATE missions SET criteria=? WHERE id=?").run(JSON.stringify([...m.criteria, c]), id);
  }
  remember(confidence: Confidence, text: string, source: string): void {
    this.db.prepare("INSERT INTO memory(confidence,text,source,created) VALUES(?,?,?,?)")
      .run(confidence, text, source, new Date().toISOString());
  }
  listMemory(): Array<{ confidence: string; text: string; source: string; created: string }> {
    return this.db.prepare("SELECT confidence,text,source,created FROM memory ORDER BY id").all() as never;
  }
}
