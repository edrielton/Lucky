import { execFile } from "node:child_process";

/** Executa SEM shell (metacaracteres já são negados pela política). */
export function runCommand(command: string, cwd: string, timeoutMs = 60_000): Promise<{ code: number; output: string }> {
  const [file, ...args] = command.trim().split(/\s+/);
  return new Promise((resolve) => {
    execFile(
      file,
      args,
      { cwd, timeout: timeoutMs, maxBuffer: 1_000_000, shell: process.platform === "win32" },
      (err, stdout, stderr) => {
        const raw = (err as { code?: unknown } | null)?.code;
        const code = err ? (typeof raw === "number" ? raw : 1) : 0;
        resolve({ code, output: `${stdout}${stderr}`.slice(0, 20_000) });
      },
    );
  });
}
