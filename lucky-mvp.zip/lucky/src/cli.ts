import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import readline from "node:readline/promises";
import { runAgent } from "./agent/loop.ts";
import { openDb } from "./db.ts";
import { ApprovalGate } from "./kernel/approval.ts";
import { Audit } from "./kernel/audit.ts";
import { NullProvider, OllamaProvider, OpenAICompatProvider } from "./model/providers.ts";
import { Store, type Criterion } from "./store.ts";
import { builtinTools } from "./tools/builtin.ts";
import type { Mode, ModelProvider } from "./types.ts";
import { verifyCriteria } from "./verify.ts";

function makeProvider(): ModelProvider {
  const kind = process.env.LUCKY_PROVIDER ?? "none";
  const model = process.env.LUCKY_MODEL ?? "qwen2.5:7b"; // troque conforme seu hardware
  if (kind === "ollama") return new OllamaProvider(process.env.LUCKY_BASE_URL ?? "http://localhost:11434", model);
  if (kind === "openai") return new OpenAICompatProvider(process.env.LUCKY_BASE_URL ?? "http://localhost:8080/v1", model, process.env.LUCKY_API_KEY);
  return new NullProvider();
}

function parseCriterion(s: string): Criterion | string {
  if (s.startsWith("existe:")) return { type: "file_exists", path: s.slice(7) };
  if (s.startsWith("contem:")) {
    const [p, ...t] = s.slice(7).split("::");
    return p && t.length ? { type: "file_contains", path: p, text: t.join("::") } : "use contem:<arquivo>::<texto>";
  }
  if (s.startsWith("cmd:")) return { type: "command_ok", command: s.slice(4) };
  return "use existe:<arquivo> | contem:<arquivo>::<texto> | cmd:<comando>";
}

async function main() {
  const workspace = path.resolve(process.env.LUCKY_WORKSPACE ?? "workspace");
  const home = path.resolve(process.env.LUCKY_HOME ?? path.join(os.homedir(), ".lucky"));
  const mode = (process.env.LUCKY_MODE ?? "ask") as Mode;
  fs.mkdirSync(workspace, { recursive: true });
  if (!path.relative(workspace, home).startsWith("..")) {
    throw new Error("LUCKY_HOME não pode ficar dentro do workspace (o agente alcançaria o próprio kernel).");
  }

  const db = openDb(home);
  const audit = new Audit(db);
  const store = new Store(db);
  const provider = makeProvider();
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const gate = new ApprovalGate(async (summary, hash) => {
    console.log(`\n⚠ APROVAÇÃO NECESSÁRIA [${hash.slice(0, 8)}]\n${summary}`);
    return /^(s|sim|y|yes)$/i.test((await rl.question("Aprovar? (s/N) ")).trim());
  });
  const deps = { provider, tools: builtinTools, workspace, home, mode, gate, audit };

  console.log(`Lucky 0.1 — modelo: ${provider.name} · modo: ${mode} · workspace: ${workspace}`);
  console.log("Comandos: status · tarefas · memória · lembrar <texto> · desenvolva <objetivo> · criterio <id> <crit> · execute missão <id> · concluir <id> · sair");

  for (;;) {
    const line = (await rl.question("\nlucky> ")).trim().replace(/^lucky,?\s*/i, "");
    const [cmd, ...rest] = line.split(/\s+/);
    const arg = rest.join(" ");
    try {
      if (!line) continue;
      if (cmd === "sair") break;
      else if (cmd === "status") {
        const v = audit.verify();
        console.log(`modelo: ${provider.name}\nmodo: ${mode}\nmissões: ${store.listMissions().length}\nauditoria: ${audit.count()} registros · integridade: ${v.ok ? "OK" : `QUEBRADA no registro ${v.brokenAt}`}`);
      } else if (cmd === "tarefas") {
        for (const m of store.listMissions()) console.log(`[${m.id}] ${m.status.padEnd(17)} ${m.goal} (${m.criteria.length} critérios)${m.result ? "\n   → " + m.result : ""}`);
      } else if (cmd === "memória" || cmd === "memoria") {
        for (const r of store.listMemory()) console.log(`[${r.confidence}] ${r.text}  (fonte: ${r.source})`);
      } else if (cmd === "lembrar") {
        store.remember("confirmed", arg, "usuário");
        console.log("ok");
      } else if (cmd === "desenvolva") {
        const m = store.createMission(arg);
        audit.log("mission", "-", `criada ${m.id}: ${arg}`);
        console.log(`Missão ${m.id} criada. Defina critérios verificáveis (criterio ${m.id} ...) e rode: execute missão ${m.id}`);
      } else if (cmd === "criterio") {
        const [id, ...c] = rest;
        const parsed = parseCriterion(c.join(" "));
        if (typeof parsed === "string") console.log(parsed);
        else { store.addCriterion(id, parsed); audit.log("criterion", "-", `${id}: ${c.join(" ")}`); console.log("critério adicionado"); }
      } else if (cmd === "execute") {
        const m = store.getMission(rest[1] ?? "");
        if (!m) { console.log("missão não encontrada"); continue; }
        store.setStatus(m.id, "RUNNING");
        try {
          const r = await runAgent(deps, m.goal);
          console.log(`\n${r.text}\n(passos: ${r.steps}, ações negadas: ${r.denied})`);
        } catch (e) {
          store.setStatus(m.id, "BLOCKED", (e as Error).message);
          console.log(`BLOCKED: ${(e as Error).message}`);
          continue;
        }
        const v = await verifyCriteria(m.criteria, workspace);
        console.log(v.report.join("\n"));
        if (!m.criteria.length) store.setStatus(m.id, "AWAITING_APPROVAL", "sem critérios automáticos: revisão humana necessária");
        else store.setStatus(m.id, v.ok ? "COMPLETED" : "FAILED", v.ok ? "todos os critérios verificados" : "critérios falharam");
      } else if (cmd === "concluir") {
        store.setStatus(arg, "COMPLETED", "concluída manualmente pelo usuário");
        audit.log("manual_complete", "-", arg);
      } else console.log("comando desconhecido");
    } catch (e) {
      console.log(`erro: ${(e as Error).message}`);
    }
  }
  rl.close();
}

main().catch((e) => { console.error(e.message); process.exit(1); });
