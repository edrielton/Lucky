# Relatório técnico — Lucky 0.2.6
## Memória estruturada, aprendizagem baseada em evidências e sandbox de sistema operacional

### Escopo

Atualização realizada em cópia isolada do pacote Lucky 0.2.5. O pacote 0.2.5 original foi preservado. Nenhuma publicação ou alteração em repositório remoto foi realizada.

### Implementações

#### Memory Engine
- Adicionadas tabelas `memory_items`, `experiences` e `learning_insights` no SQLite.
- Memórias agora aceitam categorias working, episódica, semântica, procedural, preferência, projeto, pesquisa e sistema.
- Cada memória estruturada mantém confiança, fonte, tags, metadados e data.
- Registros da tabela antiga `memory` são migrados para a nova estrutura sem apagar a origem.
- `lembrar` continua compatível e passa a gravar também na memória estruturada.

#### Learning Engine
- Registra resultados e falhas das ferramentas usadas pelo agente.
- Registra resultados da verificação de missões.
- Identifica falhas recorrentes somente após pelo menos duas ocorrências equivalentes.
- Guarda evidências por identificador e classifica as inferências como `observed`.
- O comando `aprender` apresenta padrões encontrados.
- Não treina pesos neurais, não altera código, objetivos, políticas ou permissões. É aprendizagem operacional determinística baseada em histórico verificável.

#### Sandbox
- Adicionado backend de execução Docker para o ciclo de autocorreção supervisionada.
- A execução experimental exige a imagem local `node:22.18-alpine`; não há download automático.
- Contêiner sem rede, filesystem-base somente leitura, workspace temporário como único bind mount gravável, usuário não-root, capacidades removidas e `no-new-privileges`.
- Limites configurados: 1 CPU, 512 MB de RAM sem swap adicional, 64 processos, 120 segundos e saída limitada a 1 MB.
- Contêiner recebe rótulo de execução para permitir encerramento em caso de timeout.
- Sem Docker ou imagem local, a autocorreção recusa executar código experimental (fail closed).
- Proteção adicional de caminhos contra traversal e links simbólicos; módulos de segurança e memória foram adicionados à lista de arquivos que a autocorreção não pode alterar.

### Validação executada

Ambiente: Node.js 22.16.0, abaixo do requisito oficial do projeto (22.18.0). Não havia Docker nem imagem local `node:22.18-alpine` disponíveis neste ambiente.

- `npm test`: **40 testes aprovados, 0 falhas**.
- `npm run selftest`: **40 testes executados, 40 aprovados**. Este executor roda localmente e não é a sandbox de sistema operacional.
- `npm run verify:integrity`: **OK; 17 arquivos críticos verificados**.
- Verificação de sintaxe Node para os módulos TypeScript alterados: passou.
- `node --check pc-extension/popup.js`: passou.
- Testes unitários verificaram migração de memória legada, persistência estruturada, detecção de falhas recorrentes, bloqueio de traversal/symlink e composição das restrições Docker.

### Pendências e limitações

- `npm run qa`: **reprovado** porque Node 22.16.0 é inferior ao mínimo 22.18.0 e `@types/node` não está instalado; portanto, o typecheck não foi certificado.
- A execução real dentro do Docker **não foi testada** neste ambiente, pois Docker e a imagem não estavam disponíveis. Os testes do ciclo supervisionado usaram uma injeção de executor local exclusivamente para validar o fluxo de aprovação; isso não constitui evidência de isolamento Docker.
- Antes de considerar a sandbox validada em Windows, instalar/iniciar Docker Desktop em modo de contêineres Linux, obter manualmente `node:22.18-alpine`, verificar `sandbox` e executar testes de integração que tentem escrever fora de `/workspace`, acessar rede, exceder cotas e ultrapassar timeout.
- A tag da imagem Docker é uma referência mutável; a cadeia de distribuição ainda precisa de verificação por digest/assinatura para garantir a identidade exata da imagem.
- O Learning Engine atual identifica padrões recorrentes; ainda não faz treinamento de modelo nem cria procedimentos automaticamente. Qualquer mudança de código continua sujeita ao ciclo supervisionado e à aprovação humana.

### Resultado

A memória estruturada e a análise determinística de experiências foram implementadas e passaram nos testes disponíveis. O ciclo de autocorreção agora exige um backend Docker e falha de forma fechada quando ele não existe. A integração real do contêiner, o typecheck com a versão suportada do Node e o QA completo permanecem pendentes; por isso, esta versão não deve ser descrita como totalmente certificada para produção.
