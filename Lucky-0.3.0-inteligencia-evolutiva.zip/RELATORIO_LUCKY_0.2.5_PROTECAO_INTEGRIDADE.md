# Relatório técnico — Lucky 0.2.5: detecção de adulteração

## Escopo

Implementado em cópia isolada a partir do pacote Lucky 0.2.4. O ZIP original não foi alterado e nenhuma publicação foi feita no GitHub.

## Alterações

- Versão do pacote elevada para 0.2.5.
- Novo verificador SHA-256 em `src/security/integrity.ts`.
- Manifesto de hashes para arquivos críticos: `package.json`, política de comandos, aprovação, autocorreção supervisionada, executor, loop do agente, CLI, bridge e arquivos principais da extensão; o próprio verificador de integridade também está listado.
- A inicialização do CLI é bloqueada se o verificador encontrar arquivos ausentes, links simbólicos onde se espera arquivo regular, manifesto inválido ou hashes divergentes.
- Novo comando `npm run verify:integrity`.
- Testes de regressão para arquivo intacto, adulterado, ausente, manifesto inválido e link simbólico.

## Validação executada neste ambiente

- `node --experimental-strip-types --test --no-warnings test/*.test.ts`: **35 testes aprovados, 0 falhas, 0 ignorados**.
- `node --experimental-strip-types --no-warnings scripts/verify-integrity.ts`: **OK; 11 arquivos críticos verificados** (resultado anterior ao empacotamento final; deve ser repetido após qualquer alteração nos arquivos protegidos).
- Ambiente disponível: Node.js 22.16.0, abaixo do requisito declarado pelo projeto (22.18+). O QA completo de release e o typecheck com dependências locais não foram certificados nesta execução.

## Limitações de segurança

- O pacote contém código-fonte. Uma pessoa deliberadamente pode alterar o verificador e o manifesto, portanto isso não é uma barreira criptográfica contra um atacante com acesso de escrita.
- Não foi criado binário Windows assinado, certificado de assinatura, instalador com ACLs, nem proteção remota de confiança.
- O mecanismo melhora a detecção de alterações acidentais ou simples e bloqueia a inicialização quando os hashes fixos divergem; não se deve prometer que torna o programa impossível de modificar.
- A autocorreção continua limitada à cópia temporária e exige autorização humana para executar o patch e revisão final. Não há promoção automática ao projeto original.

## Próximos passos para distribuição mais forte

1. Compilar/empacotar um executável Windows a partir de uma cadeia de build controlada.
2. Assinar o executável e o instalador com certificado de code signing do distribuidor.
3. Validar a assinatura na instalação/atualização e manter a chave privada fora do pacote.
4. Testar tentativas de adulteração do executável e do instalador em uma conta Windows padrão e em uma conta administradora.
