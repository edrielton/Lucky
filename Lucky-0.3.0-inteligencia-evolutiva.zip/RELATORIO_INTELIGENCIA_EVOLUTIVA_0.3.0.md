# Relatório de engenharia — Lucky 0.3.0

## Escopo

Construída uma cópia isolada a partir do pacote Lucky 0.2.6. Esta atualização estabelece a primeira fundação executável da filosofia de Inteligência Evolutiva, sem depender de LLM ou API nos novos componentes. A branch `main` não foi modificada durante a construção e a publicação ainda não foi realizada.

## Implementações

### Raciocínio simbólico
- Fatos com origem e confiança.
- Regras com variáveis e encadeamento de inferências.
- Proveniência das conclusões (regra e índices das premissas).
- Detecção de conflitos em predicados exclusivos configurados (padrão: estado/status).
- Limites de rodadas e quantidade de fatos.

### Planejamento
- Ordenação de etapas por dependências.
- Detecção de referências inexistentes e ciclos.
- Não executa tarefas nem concede permissões.

### Avaliação evolutiva
- Compara taxa de sucesso de estratégia atual e candidata.
- Exige amostra mínima configurável.
- Só recomenda uma candidata; não ativa nem altera código automaticamente.

### CLI
- Novo comando `inteligencia`, que executa uma demonstração local dos mecanismos determinísticos e registra o diagnóstico na auditoria.

## Limitações explícitas

- O motor simbólico não equivale a raciocínio geral humano e depende de fatos/regras fornecidos.
- Não foi implementado entendimento aberto de linguagem natural sem modelo.
- O conselho de 17 ministros ainda é uma especificação conceitual, não 17 agentes executáveis.
- Não existe autoalteração autônoma de código; evolução de código permanece supervisionada.
- A execução real do Docker ainda depende de ambiente externo compatível.

## Validação nesta cópia

A suíte completa foi executada com Node.js 22.16.0: `npm test` passou com 44/44 testes e `npm run selftest` também confirmou 44 testes executados e aprovados. O comando CLI `inteligencia` foi executado sem provedor externo e apresentou inferência, plano e comparação de estratégias. O comando `aprender` recebeu uma correção de inicialização: a instância `LearningEngine` agora é criada junto ao Store.

O `npm run qa` foi executado e reprovou por dois motivos confirmados: Node 22.16.0 abaixo do mínimo 22.18.0 e ausência de `@types/node` (`TS2688`). A tentativa de `npm install --ignore-scripts --no-audit --no-fund` excedeu o tempo limite, portanto as dependências não foram instaladas. O comando `npm run verify:integrity` passou com 22 arquivos críticos verificados. A sintaxe da extensão e o manifesto MV3 passaram no QA. Docker não está instalado neste ambiente; a integração real do contêiner permanece sem validação.

## Próximos passos

1. Reexecutar QA com Node 22.18+ e dependências instaladas.
2. Validar Docker e os limites de isolamento em ambiente real.
3. Publicar a versão extraída em branch de release e abrir PR para `main`.
